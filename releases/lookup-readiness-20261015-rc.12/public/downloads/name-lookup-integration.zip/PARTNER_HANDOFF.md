# 合作方交接检查

本包lookup-readiness-20261015-rc.12是本地候选，尚未上线。管理员确认部署与设备池开放后，按本包不含设备数量的准备响应对接。

需要单独交付：HTTP BASE_URL、clientId、secret；平台内部配置已授权且已知有姓名的探测号码，不交给调用方。新Agent支持lookupRuntimeId才能出具本轮准备证明。调用方仅按ready/status判断就绪，设备数量和调度由平台内部管理。

流程：prepare（{}，持久准备键）→ready→tasks（phoneNumber，持久业务键）→按lookupId GET。每条完成立即回填name，未实名为空；处理中不回填空，服务错误不当空。准备任务和手机号业务是两类ID/键。

合作方至少测试：真实签名；准备中时503、返回ready:true后可提交；两分钟后换键仍原ID；响应丢失重试；一个号码先完成就先保存；姓名/空姓名；GET失败不重提；回填失败重读；准备过期新键、账号掉线后准备降级。五台模拟不是五台真机。

SDK默认每次HTTP30秒，POST网络错误最多再试1次且复用键；每次新Nonce/签名。保存name需同时满足ok=true与status=completed。旧客户端没调用prepare时仍有succeeded/not_found/failed，新示例兼容旧完成态；不要在一个clientId下混用旧解析器与新prepare流程。

本地和生产证据以版本回执为准；本包不含真实手机号、密钥、姓名或服务器登录信息。没有改变媒体、ADB、USB或投屏参数的授权。

每个clientId最多5条未完成业务，执行与排队合计；可并发发送5个单号码提交请求，逐条完成后补位。第6个新号码返回429 lookup_inflight_limit且不创建任务，等待原任务完成后复用原业务键重试。重复请求先防重、不多占名额；超时或等待人工仍是原任务，不应另行补发。
