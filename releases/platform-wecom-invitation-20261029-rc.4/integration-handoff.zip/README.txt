WeCom local candidate integration handoff

Read API.md. Discover devices -> submit four fields -> poll saved taskId.
client.mjs is optional, dependency-free Node.js code; no automatic POST retries.
Provide baseUrl and admin Bearer token separately. No credentials are included.
Fields: deviceNumber, appSlot, phoneNumber, remarkName. Dual apps require main/clone.
Main/clone share the physical device lock. Maximum two unfinished tasks.
After a POST timeout without taskId, preserve the original four fields to recover.
Unknown delivery is not success; do not automatically resend or switch accounts.
Local simulation passed; this candidate has NOT been pushed or deployed.
Windows native, real Postgres, physical devices and recipient receipt remain unverified.
